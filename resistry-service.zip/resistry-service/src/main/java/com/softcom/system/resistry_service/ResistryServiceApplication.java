package com.softcom.system.resistry_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResistryServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResistryServiceApplication.class, args);
	}

}
